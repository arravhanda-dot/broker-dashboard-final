# Handoff: PropEquity Broker Intelligence Dashboard

## Overview

An internal analytics dashboard for PropEquity's broker-sourcing team. It ingests broker contact sheets (CSV/XLSX) from multiple collection channels, deduplicates and enriches them, and presents the resulting broker universe across five analytical views — pan-India overview, deal segment, statewise/micro-market, developer & project linkage, and daily intake.

The current prototype is **client-side only**: all data lives in browser `localStorage`, ingestion happens in the browser, and there is no server. The task is to build a real backend behind it and rebuild the UI in a production framework, preserving the exact look and the filtering semantics described below.

---

## About the design files

`Broker Intelligence.dc.html` (with `support.js`) is a **design reference created in HTML** — a working prototype that shows the intended look and behaviour. It is **not production code to port line-by-line**.

It is authored in a custom streaming-template runtime (`<x-dc>` markup + a `Component extends DCLogic` class). Do not try to adopt that runtime. Open the file in a browser to see and interact with the design; read the logic class to understand the business rules; then **recreate it in the target codebase's environment** using that codebase's established patterns.

If no frontend environment exists yet, React + TypeScript is the natural choice — the prototype's logic class maps almost directly onto a React component tree with a server-backed query layer.

## Fidelity

**High fidelity.** Colours, typography, spacing, radii, animation timings and copy are all final and are documented exactly below. Recreate the UI pixel-for-pixel. The one open decision is the visual system itself — see "Design system conflict" at the end.

---

## Data model

The single core entity is a **broker record**. Every field below exists in the prototype and drives at least one view.

| Field | Type | Notes |
|---|---|---|
| `name` | string | Broker's personal name. Falls back to `"Broker <n>"` when the sheet has no name column. |
| `firm` | string | Agency / company name. `"—"` when absent. |
| `city` | string | `"—"` when absent. |
| `state` | string | One of 36 Indian states/UTs. `"—"` when absent. |
| `micro` | string | Micro-market / locality within the city. Often blank — this is a tracked data gap. |
| `type` | enum | `Individual` \| `Agency` |
| `segment` | enum | `Premium` \| `Luxury` \| `Ultra premium` |
| `registered` | boolean | RERA registration status. |
| `rera` | string | RERA registration number. Blank + `registered=true` is a tracked data gap. |
| `affiliation` | enum | `NAR India` \| `NAREDCO` \| `CREDAI` \| `FIABCI` \| `None` |
| `market` | string[] | Subset of `["Primary","Secondary"]` |
| `txn` | string[] | Subset of `["Sale","Rental"]` |
| `asset` | string[] | Subset of `["Residential","Commercial"]` |
| `developer` | string | Builder the broker is empanelled with. Blank = tracked gap. |
| `project` | string | Specific project held. Blank while `developer` is set = tracked gap. |
| `projects` | int | Count of linked projects. |
| `addedOn` | date (`YYYY-MM-DD`) | Ingestion date, used by all daily-intake views. |
| `source` | enum | One of the seven sources below, or `Unspecified`. |
| `channel` | string | Sub-source within the parent `source`. Optional. |
| `_b` | string | Batch/file id — foreign key to the ingestion log entry. |

**Important:** `market`, `txn` and `asset` are **arrays, not single values**. A broker legitimately holds several at once. Almost every modelling mistake in this domain comes from treating them as scalars.

### Ingestion log entity

One row per uploaded file.

| Field | Type | Notes |
|---|---|---|
| `id` | string | Batch id, referenced by `broker._b`. |
| `name` | string | Original filename. |
| `src` | enum | Parent source assigned to the whole file. |
| `chan` | string | Sub-source, when the file was logged against a specific channel. |
| `added` / `dupes` / `upd` | int | Ingestion outcome counts. |
| `rowCount` | int | Rows actually appended. |
| `at` / `on` | string | Ingestion time and date. |

---

## Source taxonomy

Two top-level groups, seven sources, fourteen channels. This hierarchy drives the Daily intake section and the per-file source tagging on upload. It should be **reference data in the database**, not hardcoded — the team adds channels over time.

**Group: PropEquity** — in-house teams, portals, registries and inbound

| Source | Channel | Owner |
|---|---|---|
| P Plus | Broker team / primary team | Pooja |
| P Plus | Market research resale calling | Pooja |
| P Plus | Samir Jasuja calls | Sajjad |
| P Plus | Winners list | Pooja |
| P Plus | PropEquity Land | Pratik |
| Listings | MagicBricks, Housing.com, 99acres | Sajjad |
| Listings | Squareyards | Sajjad |
| Listings | 1acre.in | Sajjad |
| RERA | State RERA agent registries | Pooja |
| Inbound | Website and YouTube inquiries | Niraj |
| Inbound | WhatsApp inquiries | Niraj |
| Community | Broker WhatsApp groups | Ashish |
| Field survey | Bombay project visits | Pooja |

**Group: PropEdge** — banking and NBFC valuation channel

| Source | Channel | Owner |
|---|---|---|
| PropEdge | Retail valuation brokers via CRM | Sajjad |
| PropEdge | Tier-1 · 1,161 under-construction projects | Pooja |
| PropEdge | Tier-2 · all under-construction projects | Pooja |

Each channel also carries a one-line description of how the data is actually obtained — see `SOURCE_DETAIL` in the prototype for the exact strings; they are user-facing copy and should be preserved.

Source accent colours: P Plus `#3DD4A7` · PropEdge `#A78BFA` · Listings `#5B9DFF` · RERA `#F5B458` · Inbound `#2DD4BF` · Community `#A78BFA` · Field survey `#2DD4BF` · Unspecified `#5E6A7E`.

---

## Backend requirements

### 1. Ingestion API

`POST /api/ingest` — multipart upload, accepts `.csv`, `.xlsx`, `.xls`, one or more files per request, with an optional `source` and `channel` to stamp onto every row in the file.

**Column mapping.** Headers are normalised by lowercasing and stripping all non-letters, then matched against an alias list. Port these aliases exactly:

| Field | Accepted header aliases (post-normalisation) |
|---|---|
| name | `name`, `brokername`, `fullname`, `contactname` |
| firm | `firm`, `firmname`, `company`, `agencyname`, `organisation` |
| city | `city`, `location` |
| state | `state`, `region` |
| micro | `micromarket`, `micromkt`, `locality`, `sector`, `area` |
| type | `type`, `brokertype`, `category`, `classification` |
| segment | `segment`, `dealsegment` |
| registration | `registration`, `registered`, `rerastatus`, `status`, `registrationstatus` |
| rera | `reranumber`, `rerano`, `registrationnumber`, `reraid` |
| affiliation | `affiliation`, `professionalaffiliation`, `association`, `membership` |
| market | `market`, `primarysecondary`, `mandate`, `marketsegment` |
| txn | `transaction`, `salerental`, `dealtype`, `transactiontype` |
| asset | `asset`, `assetclass`, `residentialcommercial`, `propertytype` |
| developer | `developer`, `developerlinked`, `builder`, `developername` |
| project | `project`, `projectname`, `linkedproject`, `projectmapped` |
| projects | `projects`, `projectslinked`, `projectcount`, `linkedprojects` |
| addedOn | `addedon`, `dateadded`, `collectedon`, `date`, `createdon` |
| source | `source`, `datasource`, `sourcedfrom`, `collectedfrom`, `channel` |

**Value coercion.**
- `type` → `Agency` if the raw value matches `/agenc|firm|compan|channel/i`, else `Individual`.
- `segment` → `Ultra premium` if `/ultra/i`, `Luxury` if `/lux/i`, else `Premium`.
- `affiliation` → matched against `/nar\b|narindia/i`, `/naredco|nardeco/i`, `/credai/i`, `/fiabci/i`, else `None`.
- `registered` → true when the raw value starts with y/t/1 or contains "reg" **and** does not contain "unreg"/"not"; otherwise true if a RERA number is present.
- Multi-value fields (`market`, `txn`, `asset`) → substring-match the cell against each allowed value, case-insensitive, collecting all hits. If the cell is non-empty but matches nothing, default to the first allowed value. If empty, return an empty array.
- `addedOn` → parsed date, falling back to today.
- `source` → fuzzy-normalised (see `normSource` in the prototype) against the seven sources; unrecognised values become `Unspecified`.

**Deduplication.** Identity key is `lowercase(name + "|" + firm + "|" + city)`.
- New key → insert.
- Existing key, and the incoming row has a **different non-empty** `developer`, `project`, `micro` or `projects` → **update** those fields (plus `rera`, and set `registered=true` if a RERA number arrived). Count as an update.
- Existing key, nothing changed → count as a duplicate, discard.

The response must return per-file `added` / `dupes` / `updated` counts — the UI displays all three.

Unreadable files must not abort the batch; log them with zero counts and continue.

### 2. Query API

`GET /api/brokers` with filters, sort, and pagination. The filter semantics are the subtle part — get these exactly right:

- **Within one filter group** (e.g. two states selected) → **OR**.
- **Across different groups** (state AND affiliation) → **AND**.
- **Free-text search** `q` → matches across name, firm, city, state, micro, developer, project.
- **Day filter** → exact `addedOn` match.
- **Mandate-box filter** (the Deal segment checkboxes) → **exact-set match**, described in full below.

### 3. The mandate-box filter — exact-set semantics

The Deal segment section presents a 2 × 3 grid of cells: `{Residential, Commercial} × {Primary, Secondary, Rental}`.

Derive a broker's **cell coverage** as follows. For each asset in `broker.asset`, for each bucket:
- `Primary` → `broker.market` contains "Primary" **and** `broker.txn` contains "Sale"
- `Secondary` → `broker.market` contains "Secondary" **and** `broker.txn` contains "Sale"
- `Rental` → `broker.txn` contains "Rental"

Each hit yields a cell key `"<Asset>|<Bucket>"`.

A broker matches the selection **only when their cell coverage set is exactly equal to the selected set** — same size, same members. A broker who covers the selected cells *plus others* is excluded.

This is deliberate and was specifically requested: the user wants "brokers who *only* work in these segments", not "brokers who work in these among other things". The UI copy states it explicitly — "*anyone who also deals elsewhere is excluded*".

> **Why it matters:** an earlier version used overlap (`OR`) then superset (`AND`) semantics. Both produced counts that summed past 100% and misrepresented the pool. Exact-set is the only version where every broker falls into exactly one bucket and the numbers add up. Do not "optimise" this back into an overlap query.

### 4. Data-gap detection

Five gap types, evaluated per broker, surfaced as clickable filter chips:

| Gap | Condition |
|---|---|
| Developer not mapped | `!developer` |
| Project not mapped | `developer && !project` |
| RERA no. missing | `registered && !rera` |
| Micro market missing | `!micro` |
| City / state missing | `!city \|\| city === "—" \|\| !state \|\| state === "—"` |

### 5. Manual classification

`PATCH /api/brokers/:id/mandate` — sets `market`, `txn`, `asset`. In the prototype these overrides are stored separately, keyed by the broker identity key, and re-applied over the ingested data on every load, so a re-upload never clobbers a human decision. **Preserve that behaviour** — store manual classifications as a separate overlay table, not as a mutation of the ingested row.

### 6. Export

`GET /api/brokers/export` — CSV of the **currently filtered and sorted** set, all 16 columns, respecting every active filter.

### 7. Reference data to seed

- 36 states with their cities (~211 cities total).
- Per-city micro-market zone maps, grouped North / South / East / West / Central.
- Developer lists per state, and project lists per developer.
- The source/channel/owner taxonomy above.

All of this is currently hardcoded as constants at the top of the prototype's script block (`STATES`, `MICRO`, `ZONE_OF`, `DEV_BY_STATE`, `PROJECTS`). Lift the values directly — they are curated, not generated.

### 8. Replaces `localStorage`

The prototype persists `{rows, log, tags, source}` under the key `pe-broker-db-v1`, debounced 400 ms after any state change, and restores on mount. All of this becomes server state. Keep a lightweight client cache if you like, but the database is the source of truth.

---

## Screens / views

The shell is a fixed left sidebar (filters + ingestion) and a scrolling content column. **Pan-India overview is always visible and locked**; the other four sections toggle on and off independently beneath it via the nav — active sections show a green dot. Sections stack in nav order; they do not replace each other.

### Shell

- **Left sidebar** — brand lockup, live clock (`Live · HH:MM:SS`, ticking every second), nav list, ingestion drop zone, collapsible filter groups.
- **Filter bar** (top of content) — search input, active-filter count, applied-filter chips (each removable), "Reset filters", density toggle, CSV export, match line `<filtered> / <total>`.
- **Content column** — the section cards, then the broker table.

### Filter groups (sidebar, collapsible)

Registration · Broker type · Affiliation · Residential/Commercial · Developer (top 20) · Project (top 24) · State (all 36) · City (top 120) · Micro market (top 200) · Data gaps (5).

Each group header shows a badge — the selection count, or `All`. Each option row shows a checkbox, the label, and a live count computed **excluding that group's own selection** (so counts don't collapse to zero as you select).

### 1. Pan-India overview (locked)

- Header strip: "Total pan-India brokers" + registered/unregistered split with percentages + today's delta.
- Hero number: 52px, weight 750, gradient text `linear-gradient(100deg,#E7ECF3,#3DD4A7)`, tabular numerals.
- Four meta tiles, each with a 2px `#252C3A` left border: label 9px uppercase mono `#5E6A7E`, value 19px weight 700, sub-line 10.5px `#9AA6B8`.
- Daily intake sparkline: 21 vertical bars, last 21 days, min height 3px, max 118px. Today's bar is a green gradient; the last 7 days are `#3F6E80`; older bars `#2A3444`. Click any bar to isolate that day.

### 2. Deal segment

- Two columns — Residential (`#5B9DFF`) and Commercial (`#F5B458`) — each containing three checkbox rows: Primary, Secondary, Rental.
- Checkbox: 15 × 15px, 4px radius, 1px border. Unchecked border `#313A4E`; checked fills with the column colour, tick glyph `#0B0E14`.
- **The boxes carry no counts or bars.** This was a deliberate removal — per-box counts overlapped and misled. All counting happens in the single readout.
- Column header is a button that ticks all three of its boxes; sub-label reads "tick all three — residential only" / "all three ticked".
- A dropdown of 21 preset combinations (3 asset sets × 7 mandate sets). Selecting one **ticks the equivalent boxes**; ticking boxes by hand syncs the dropdown back, or blanks it if the selection isn't a preset. It is a shortcut for the checkboxes, not an independent filter.
- "+ Log a broker" opens a searchable picker to classify a broker into the current combination.
- **Readout** below the columns: 26px mono number (`#A78BFA` when a selection is active, `#E7ECF3` otherwise) plus a sentence naming the exact selection.

### 3. Statewise

- "Brokers by state" — top 12 states as a 4-column grid row (`136px 1fr 56px 44px`): name, 14px bar track (`#161B24`, 4px radius, fill `#5B9DFF` / `#7FB6FF` when selected), count, percentage. Click to filter.
- Footnote naming the active mandate selection.
- "Micro markets" panel — every city with brokers, showing broker count and region count. Click a city to open a **zone modal** with its localities grouped North / South / East / West / Central.

### 4. Developer & project linked

- "Brokers affiliated per builder" — top 8 developers.
- "Brokers per project" — top 8 projects.
- Three data-gap cards: developer not mapped, project not mapped, RERA number missing.

### 5. Daily intake

- **Source cards**, grouped PropEquity / PropEdge. Each card: source name, today's delta in the source's accent colour, cumulative total, a magnitude bar, a one-line description, and a footer reading `N channels · N sheets` with a chevron.
- Clicking a card **expands a detail panel** beneath the card grid — accent left border 3px, listing each channel as a numbered row: index (mono, accent), channel name (12.5px, weight 600), owner chip (8.5px uppercase mono on `rgba(255,255,255,0.06)`, pill), the sourcing description (11px `#8A96A8`), then a counts line (`N sheets · N records`, or "No sheet logged yet") and a dashed **"+ Log dataset"** button that uploads directly into that channel.
- Panel header carries a "Filter to <source>" / "Clear filter" pill — filtering is deliberately separate from expanding, so browsing sourcing doesn't disturb active filters.
- "New additions by state" panel for today's batch.
- Two data-gap cards: micro market missing, city/state missing.
- **Ingestion log** — one row per uploaded file with filename, time, added/dupes/updated counts, a source dropdown, and a delete action. Files with no source assigned show a red border on the dropdown.

### Broker table

Ten columns: Broker · City · state · Type · RERA · Segment · Deals in · Affiliation · Developer · project · Projects · Added. Sortable on name, place, type, segment, projects, added. Sticky header (`#1C2230`, 9.5px uppercase mono, active column `#3DD4A7`). Row height driven by a density toggle (`7px 10px` normal / `4px 10px` dense). Paginated, default 12 per page. The "Deals in" cell is a button that opens the classify modal; unclassified rows read "Not classified — tap to set" in `#F5B458`.

### Modals

- **Classify mandate** — 400px, `#141A24`, 14px radius, combination chips for deal mandate and asset class.
- **Broker picker** — search + result list, for logging a broker into a chosen mandate.
- **City zones** — locality lists by compass zone.

---

## Interactions & behaviour

- Filter selection updates every panel, the table, and the counts simultaneously. No apply button.
- Toggling a nav section shows/hides that section; Pan-India overview cannot be turned off.
- `Escape` closes the open filter group.
- Source card expansion is single-open — opening one closes the other.
- Dropping the last ingested file restores the seeded sample.
- The seeded sample is discarded automatically on the first real upload.

## Motion

| Element | Animation |
|---|---|
| Card entry | `peRise` 0.46–0.54s `cubic-bezier(0.16,1,0.3,1)`, staggered 0.06s per panel |
| Bar growth | `peGrow` 0.85s `cubic-bezier(0.16,1,0.3,1)`, `transform-origin: left` |
| Bar width change | 0.48–0.72s `cubic-bezier(0.16,1,0.3,1)` |
| Row/card hover, selection | 0.24–0.32s `cubic-bezier(0.4,0,0.2,1)` |
| Chevron rotate | 0.24s, 45° → −135° |
| Micro transitions | 0.15–0.16s |

---

## Design tokens

### Colour

| Role | Hex |
|---|---|
| App background | `#0B0E14` |
| Card background | `linear-gradient(180deg, rgba(26,32,44,0.66), rgba(18,23,31,0.72))` with `backdrop-filter: blur(20px) saturate(170%)` |
| Card border | `rgba(255,255,255,0.07)` |
| Panel / input background | `#12171F`, `#0E131B` |
| Elevated surface | `#141A24`, `#1C2230` |
| Divider | `#1F2634`, `#252C3A` |
| Track | `#1C2230`, `#161B24` |
| Body text | `#E7ECF3` |
| Secondary text | `#9AA6B8` |
| Muted text | `#5E6A7E` |
| Accent 1 (green) | `#3DD4A7` |
| Accent 2 (blue) | `#5B9DFF` |
| Accent 3 (amber) | `#F5B458` |
| Accent 4 (violet) | `#A78BFA` |
| Accent 5 (teal) | `#2DD4BF` |
| Accent 6 (pink) | `#F472B6` |
| Danger | `#FF5C6C` |

### Typography

- UI: system sans stack.
- Numerals, labels, codes: **IBM Plex Mono**, with `font-variant-numeric: tabular-nums`.
- Scale (px): 8.5 · 9 · 9.5 · 10 · 10.5 · 11 · 11.5 · 12 · 12.5 · 13 · 14 · 15 · 19 · 26 · 52.
- Weights: 500 · 550 · 600 · 650 · 700 · 750.
- Uppercase mono labels: `letter-spacing` 0.06–0.13em.
- Headings: `letter-spacing` −0.005 to −0.03em.

### Spacing, radius, shadow

- Spacing: 2 · 3 · 4 · 5 · 6 · 7 · 8 · 9 · 10 · 11 · 12 · 13 · 14 · 16 · 20 · 22px.
- Radius: 4px checkboxes/bars · 6–8px rows and inputs · 9–10px inner cards · 12px columns · 14px section cards · 20px pills · 9999px dots.
- Shadow: `0 1px 2px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.07)` on cards; `0 20px 60px rgba(0,0,0,0.5)` on modals.
- Grid: `repeat(auto-fit, minmax(min(100%, Npx), 1fr))` throughout — every panel reflows.

---

## Assets

None. No images, no icon font — all glyphs are Unicode (`✓ × · — →`) or CSS-drawn (the chevron is a rotated two-sided border). IBM Plex Mono is the only web font.

---

## Design system conflict — decide before building

The prototype is a **dark glass-morphism** interface: translucent gradient cards, backdrop blur, coloured glow shadows, gradient text.

PropEquity's official design system specifies the opposite — flat white/navy surfaces, Open Sans, primary blue `#0A72D2`, navy `#0F1040`, CTA orange `#DD7F43`, 4px/8px radii, and it explicitly prohibits glassmorphism, gradients and glow effects.

The user has confirmed **keep dark** for this internal tool. Build it as documented here. But if this dashboard is ever surfaced to clients or embedded in a PropEquity product, it will need re-skinning onto the official system — so keep colour and typography in tokens rather than inline, to make that swap cheap.

---

## Known open items

1. **No measure of broker value.** Every attribute is categorical — what they deal in, where, registered or not. There is no volume, recency, or deal-size signal, so the dashboard can tell you a broker exists but not whether they are worth calling. `projects` is the only weight available. Adding a last-activity or deal-count column to the ingestion schema would be the single highest-value data change.
2. **Source cards mix real and sample numbers** while the seeded sample is loaded — the broker count is sample-derived, the sheet count is real. This resolves itself once real data is ingested, and disappears entirely once the backend exists.
3. **The archetype classifier was removed.** A 7-bucket true split (Pan-mandate, Dual-asset dealmaker, Full-stack residential, Residential specialist, Full-stack commercial, Commercial specialist, Unclassified) was built and working but never displayed, so it was deleted as dead code. It is the only non-overlapping way to summarise broker mix and is worth rebuilding server-side as a derived column. The classification rule: count the buckets the broker covers (`Primary`/`Secondary`/`Rental`) and the assets; both assets → `Pan-mandate` if all three buckets else `Dual-asset dealmaker`; single asset → `Full-stack <asset>` if all three buckets, else `<asset> specialist`; no coverage → `Unclassified`.

---

## Files in this bundle

| File | What it is |
|---|---|
| `Broker Intelligence.dc.html` | The design prototype. Open in a browser to interact with it. The `<x-dc>` block is the markup; the `<script data-dc-script>` block holds all business logic, reference data, and the parsing/dedup/filter rules described above. |
| `support.js` | Runtime required for the prototype to render. Not part of the deliverable — do not port it. |

The authoritative source for anything not spelled out in this README is the logic class in the prototype. In particular, read `parseRows` (column mapping), `onFile` (dedup), `matches` (filter semantics), and `normSource` (source fuzzy-matching) before implementing the backend.
